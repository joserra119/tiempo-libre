-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 23-12-2019 a las 20:51:40
-- Versión del servidor: 5.7.28-0ubuntu0.16.04.2
-- Versión de PHP: 7.0.33-0ubuntu0.16.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tiempolibre`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(255) NOT NULL,
  `receptor` int(255) DEFAULT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `emisor` int(255) DEFAULT NULL,
  `publicacion` int(255) DEFAULT NULL,
  `nota` int(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id`, `receptor`, `comentario`, `emisor`, `publicacion`, `nota`, `fecha`) VALUES
(1, 8, 'Muy buen trabajo', 9, 1, 5, '2019-12-19'),
(2, 8, 'Muy mal trabajo', 9, 2, 1, '2019-12-19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensaje_privado`
--

CREATE TABLE `mensaje_privado` (
  `id` int(255) NOT NULL,
  `emisor` int(255) DEFAULT NULL,
  `receptor` int(255) DEFAULT NULL,
  `mensaje` longtext,
  `createt_at` datetime DEFAULT NULL,
  `archivo` varchar(255) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `leido` varchar(3) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `publicacion` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(255) NOT NULL,
  `usuario_id` int(255) DEFAULT NULL,
  `tipo` int(255) DEFAULT NULL,
  `tipo_id` int(255) DEFAULT NULL,
  `leido` varchar(3) DEFAULT NULL,
  `createt_at` datetime DEFAULT NULL,
  `extra` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE `publicaciones` (
  `id` int(255) NOT NULL,
  `usuario_id` int(255) DEFAULT NULL,
  `text` mediumtext,
  `documento` varchar(100) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `createt_at` datetime DEFAULT NULL,
  `dia_libre` datetime DEFAULT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_fin` time DEFAULT NULL,
  `asunto` varchar(255) DEFAULT NULL,
  `tipo` varchar(7) DEFAULT NULL,
  `mensajes` int(11) DEFAULT NULL,
  `cerrada` int(2) DEFAULT NULL,
  `provincia` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `publicaciones`
--

INSERT INTO `publicaciones` (`id`, `usuario_id`, `text`, `documento`, `imagen`, `estado`, `createt_at`, `dia_libre`, `hora_inicio`, `hora_fin`, `asunto`, `tipo`, `mensajes`, `cerrada`, `provincia`) VALUES
(1, 9, 'Necesito recoger un paquete en correos', NULL, NULL, NULL, '2019-12-19 16:43:18', '2020-01-07 00:00:00', '09:00:00', '14:00:00', 'Ir a correos', 'Demanda', 3, 1, 'Alicante'),
(2, 9, 'Paseo mascotas por 8 euros la hora', NULL, NULL, NULL, '2019-12-19 16:48:35', '2020-01-08 00:00:00', '07:00:00', '14:00:00', 'Paseo mascotas', 'Oferta', 2, 1, 'Alicante'),
(3, 9, 'necesito ir a correos', NULL, NULL, NULL, '2019-12-19 16:52:33', '2019-01-01 00:00:00', '10:00:00', '12:00:00', 'Ir a correos', 'Demanda', NULL, 0, 'Alicante');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(255) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nick` varchar(50) DEFAULT NULL,
  `biografia` varchar(255) DEFAULT NULL,
  `activo` varchar(2) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `role`, `email`, `nombre`, `apellidos`, `password`, `nick`, `biografia`, `activo`, `imagen`) VALUES
(6, 'ROLE_USER', 'raul@hotmail.com', 'raul', 'garcia', '$2y$04$RMmijt8Ycvv9ARQ0CuM4ae.wMrWmomP6PXHSQcm/d6tvaQcTcMAZa', 'raul', 'Estudiante de derecho', NULL, NULL),
(7, 'ROLE_ADMIN', 'joserra1109@hotmail.com', 'Jose Ramon', 'Castillejos Moreno', '$2y$04$/wSlgS.jISe8qc7qY25/mupyXA.a.OQHr9wUbMrYO9u8wI7.AYDxS', 'joserra', NULL, NULL, '71567017325.png'),
(8, 'ROLE_USER', 'elisabeth@gmail.com', 'elisabeth', 'boronat gonzalez', '$2y$04$CMW.Ke4OUQTcxRJTHTiaK.6Z1lDpC5YvHsKA78RuY/DyAXyFJZpoG', 'eli', 'Estudiante de criminología', NULL, '81573403455.jpeg'),
(9, 'ROLE_USER', 'antonio@hotmail.com', 'antonio', 'lloret llorca', '$2y$04$nc3jDUYU1LUNHxJpPTn/zuWOwsjxa3Xm19t.aep1zjBHjG9yrsTA.', 'antonio', 'Estudiante de magisterio', NULL, '1576770126.jpeg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comentarios_usuarios` (`receptor`),
  ADD KEY `fk_comentrarios_emisor` (`emisor`),
  ADD KEY `fk_comentarios_publicaciones` (`publicacion`);

--
-- Indices de la tabla `mensaje_privado`
--
ALTER TABLE `mensaje_privado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mensaje_emisor` (`emisor`),
  ADD KEY `fk_mensaje_receptor` (`receptor`),
  ADD KEY `fk_foreign_key_publicacion` (`publicacion`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notificaciones_usuarios` (`usuario_id`);

--
-- Indices de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_publicaciones_usuarios` (`usuario_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuarios_campos_unicos` (`email`,`nick`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `mensaje_privado`
--
ALTER TABLE `mensaje_privado`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `fk_comentarios_emisor` FOREIGN KEY (`emisor`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_comentarios_publicaciones` FOREIGN KEY (`publicacion`) REFERENCES `publicaciones` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_comentarios_usuarios` FOREIGN KEY (`receptor`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `mensaje_privado`
--
ALTER TABLE `mensaje_privado`
  ADD CONSTRAINT `fk_foreign_key_publicacion` FOREIGN KEY (`publicacion`) REFERENCES `publicaciones` (`id`),
  ADD CONSTRAINT `fk_mensaje_emisor` FOREIGN KEY (`emisor`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_mensaje_receptor` FOREIGN KEY (`receptor`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `fk_notificaciones_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD CONSTRAINT `fk_publicaciones_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
